﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace zd2_Varaxin
{
    public partial class FormParams : Form
    {
        PhoneBook phoneBook;
        string file_name;

        public FormParams(PhoneBook _phoneBook)
        {
            phoneBook = _phoneBook;
            InitializeComponent();
            if (phoneBook.ListPhone().Count > 0)
            {
                listBox_phone.Items.AddRange((from con in phoneBook.ListPhone()
                                              select con.Info()).ToArray<string>());
            }

        }

        public FormParams(PhoneBook _phoneBook, string _file_name)
        {
            file_name = _file_name;
            phoneBook = _phoneBook;
            if (phoneBook.ListPhone().Count > 0)
            {
                listBox_phone.Items.AddRange((from con in phoneBook.ListPhone()
                                              select con.Info()).ToArray<string>());
            }
            InitializeComponent();
        }

        private bool CheckTextBox(System.Windows.Forms.TextBox textBox)
        {
            if (textBox.Text == "")
            {
                textBox.BackColor = Color.IndianRed;
                return false;
            }

            return true;
        }

        private bool CheckPhone(System.Windows.Forms.TextBox textBox)
        {
            string pattern = @"(\(?\d{3}\)?[\- ]?)?[\d\- ]{7,10}$";

            if (Regex.IsMatch(textBox.Text, pattern)) return true;

            textBox.BackColor = Color.IndianRed;
            return false;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void but_add_contact_Click(object sender, EventArgs e)
        {
            if (phoneBook == null)
            {
                text_name.Text = "";
                text_phone.Text = "";

                MessageBox.Show("Отсутствует файл", "Добавление контакта");
                return;
            }

            text_name.BackColor = Color.White;
            text_phone.BackColor = Color.White;

            if (CheckTextBox(text_name) & CheckPhone(text_phone) && CheckTextBox(text_phone))
            {
                Contact new_contact = new Contact(text_name.Text, text_phone.Text);
                phoneBook.AddContact(new_contact);
                listBox_phone.Items.Add(new_contact.Info());

                text_name.Text = "";
                text_phone.Text = "";
            }
        }

        private void but_del_contact_Click(object sender, EventArgs e)
        {
            if (phoneBook == null)
            {
                text_name_del.Text = "";
                text_phone_del.Text = "";

                MessageBox.Show("Отсутствует файл", "Удаление контакта");
                return;
            }
            if (phoneBook.ListPhone().Count == 0)
            {
                text_name_del.Text = "";
                text_phone_del.Text = "";

                MessageBox.Show("Телефонная книга пуста", "Удаление контакта");
                return;
            }

            if (text_name_del.Text == "" && text_phone_del.Text == "")
            {
                text_name_del.BackColor = Color.IndianRed;
                text_phone_del.BackColor = Color.IndianRed;
                return;
            }

            text_name_del.BackColor = Color.White;
            text_phone_del.BackColor = Color.White;

            if (phoneBook.RemoveContact(text_name_del.Text, text_phone_del.Text, out int ind))
            {
                text_name_del.Text = "";
                text_phone_del.Text = "";
                listBox_phone.Items.RemoveAt(ind);
            }
            else
            {
                MessageBox.Show("Контакт не найден", "Удаление контакта");
            }
        }

        private void but_load_Click(object sender, EventArgs e)
        {
            string fname = "";

            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "All files (*.*)|*.*";
                openFileDialog.FilterIndex = 0;
                openFileDialog.RestoreDirectory = true;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    fname = openFileDialog.FileName;
                }
            }

            if (fname == "") return;

            if (new FileInfo(fname).Extension == ".csv")
            {
                listBox_phone.Items.Clear();
                PhoneBookLoader.Load(phoneBook, fname);
                listBox_phone.Items.AddRange((from con in phoneBook.ListPhone()
                                              select con.Info()).ToArray<string>());
            }
            else
            {
                MessageBox.Show("Ошибка расширения файла.\nНужен .csv", "Выгрузка из файла");
            }
        }

        private void but_exit_Click(object sender, EventArgs e)
        {

            this.Close();
        }

        private void but_save_Click(object sender, EventArgs e)
        {
            string filename;
            using (SaveFileDialog saveFileDialog = new SaveFileDialog())
            {
                saveFileDialog.Filter = "CSV files (*.csv) | *.csv";

                if (saveFileDialog.ShowDialog() == DialogResult.Cancel)
                    return;
                filename = saveFileDialog.FileName;
            }

            if (string.IsNullOrEmpty(filename)) return;

            try
            {

                PhoneBookLoader.Save(phoneBook, filename);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при сохранении", "Сохранение в файл");
            }

        }

        private void listBox_phone_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox_phone.SelectedIndex != -1)
            {
                Clipboard.SetText(listBox_phone.Items[listBox_phone.SelectedIndex].ToString());
            }
        }
    }
}
