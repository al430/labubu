﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.Design;

namespace zd2_Varaxin
{
    public class PhoneBook
    {
        List<Contact> phone_book = new List<Contact>();
        public string FileName { get; set; }

        public PhoneBook()
        {
        }

        public PhoneBook(string fileName)
        {
            FileName = fileName;
        }

        public bool Search(string search_text, out Contact res)
        {
            for (int i = 0; i < phone_book.Count; i++)
            {
                if (phone_book[i].Equals(search_text))
                {
                    res = phone_book[i];
                    return true;
                }
            }

            res = null;
            return false;
        }

        public bool Search(Contact search_text, out Contact res)
        {
            for (int i = 0; i < phone_book.Count; i++)
            {
                if (phone_book[i].Equals(search_text))
                {
                    res = phone_book[i];
                    return true;
                }
            }

            res = null;
            return false;
        }

        public void AddContactSpeed(Contact contact)
        {
            phone_book.Add(contact);
        }

        public bool AddContact(Contact contact)
        {
            if (!this.Search(contact, out Contact res))
            {
                phone_book.Add(contact);
                return true;
            }

            return false;
        }

        public bool RemoveContact(Contact contact)
        {
            for (int i = 0; i < phone_book.Count; i++)
            {
                if (phone_book[i].Equals(contact))
                {
                    phone_book.RemoveAt(i);
                    return true;
                }
            }

            return false;
        }

        public bool RemoveContact(string text, out int index)
        {
            for (int i = 0; i < phone_book.Count; i++)
            {
                if (phone_book[i].Name == text || phone_book[i].Phone == text)
                {
                    phone_book.RemoveAt(i);
                    index = i;
                    return true;
                }
            }

            index = -1;
            return false;
        }

        public bool RemoveContact(string _name, string _phone, out int index)
        {
            if (_name == "")
            {
                return RemoveContact(_phone, out index);
            }
            if (_phone == "")
            {
                return RemoveContact(_name, out index);
            }

            for (int i = 0; i < phone_book.Count; i++)
            {
                if (phone_book[i].Name == _name && phone_book[i].Phone == _phone)
                {
                    phone_book.RemoveAt(i);
                    index = i;
                    return true;
                }
            }

            index = -1;
            return false;
        }

        public bool RemoveContact(int i)
        {
            if (i < phone_book.Count && i > 0)
            {
                phone_book.RemoveAt(i);
                return true;
            }

            return false;
        }

        public List<Contact> ListPhone()
        {
            return phone_book;
        }

        public void ClearListPhone()
        {
            phone_book.Clear();
        }
    }
}
