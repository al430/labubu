﻿namespace zd2_Varaxin
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            text_search = new TextBox();
            but_search = new Button();
            listBox_phone = new ListBox();
            but_params = new Button();
            but_exit = new Button();
            SuspendLayout();
            // 
            // text_search
            // 
            text_search.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            text_search.ForeColor = Color.FromArgb(0, 0, 64);
            text_search.Location = new Point(12, 12);
            text_search.Margin = new Padding(4, 3, 4, 3);
            text_search.Name = "text_search";
            text_search.Size = new Size(225, 33);
            text_search.TabIndex = 0;
            // 
            // but_search
            // 
            but_search.Font = new Font("Impact", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            but_search.ForeColor = Color.FromArgb(64, 64, 64);
            but_search.Location = new Point(236, 12);
            but_search.Margin = new Padding(4, 3, 4, 3);
            but_search.Name = "but_search";
            but_search.Size = new Size(96, 33);
            but_search.TabIndex = 1;
            but_search.Text = "Найти";
            but_search.UseVisualStyleBackColor = true;
            but_search.Click += but_search_Click;
            // 
            // listBox_phone
            // 
            listBox_phone.BackColor = SystemColors.InactiveBorder;
            listBox_phone.Font = new Font("Bahnschrift", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            listBox_phone.FormattingEnabled = true;
            listBox_phone.ItemHeight = 18;
            listBox_phone.Location = new Point(12, 64);
            listBox_phone.Margin = new Padding(4, 3, 4, 3);
            listBox_phone.Name = "listBox_phone";
            listBox_phone.Size = new Size(320, 400);
            listBox_phone.TabIndex = 2;
            // 
            // but_params
            // 
            but_params.Font = new Font("Impact", 15.75F);
            but_params.ForeColor = Color.FromArgb(64, 64, 64);
            but_params.Location = new Point(12, 470);
            but_params.Name = "but_params";
            but_params.Size = new Size(320, 42);
            but_params.TabIndex = 3;
            but_params.Text = "Параметры";
            but_params.UseVisualStyleBackColor = true;
            but_params.Click += but_params_Click;
            // 
            // but_exit
            // 
            but_exit.Font = new Font("Impact", 15.75F);
            but_exit.ForeColor = Color.FromArgb(64, 64, 64);
            but_exit.Location = new Point(12, 518);
            but_exit.Name = "but_exit";
            but_exit.Size = new Size(320, 42);
            but_exit.TabIndex = 4;
            but_exit.Text = "Выход";
            but_exit.UseVisualStyleBackColor = true;
            but_exit.Click += but_exit_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(346, 568);
            Controls.Add(but_exit);
            Controls.Add(but_params);
            Controls.Add(listBox_phone);
            Controls.Add(but_search);
            Controls.Add(text_search);
            Margin = new Padding(4, 3, 4, 3);
            Name = "Form1";
            Text = "Телефонная книга";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox text_search;
        private Button but_search;
        private ListBox listBox_phone;
        private Button but_params;
        private Button but_exit;
    }
}
