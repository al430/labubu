﻿using Microsoft.VisualBasic.FileIO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zd2_Varaxin
{
    public static class PhoneBookLoader
    {
        public static void Load(PhoneBook phoneBook, string fileName)
        {
            phoneBook.ClearListPhone();

            using (StreamReader reader = new StreamReader(fileName))
            {
                string line = " ";
                string[] line_arr;

                while (true)
                {
                    line = reader.ReadLine();

                    if (line == null || line == "") return;

                    line_arr = line.Split(';');
                    phoneBook.AddContact(new Contact(line_arr[0], line_arr[1]));
                }
            }
        }

        public static void Save(PhoneBook phoneBook, string fileName)
        {
            using (StreamWriter writer = new StreamWriter(fileName))
            {
                foreach(Contact con in phoneBook.ListPhone())
                {
                    writer.WriteLine(con.InfoFile());
                }
            }
        }
    }
}
