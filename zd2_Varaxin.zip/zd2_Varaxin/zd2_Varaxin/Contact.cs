﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zd2_Varaxin
{
    public class Contact
    {
        public string Name { get; set; }
        public string Phone { get; set; }

        public Contact(string name, string phone)
        {
            Name = name;
            Phone = phone;
        }

        public string Info()
        {
            return $"{Name} {Phone}";
        }

        public string InfoFile()
        {
            return $"{Name};{Phone}";
        }

        public bool Equals(Contact other)
        {
            return this.Phone == other.Phone;
        }

        public bool Equals(string phone)
        {
            return this.Phone == phone;
        }
    }

}
