﻿namespace zd2_Varaxin
{
    partial class FormParams
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            listBox_phone = new ListBox();
            text_name = new TextBox();
            but_add_contact = new Button();
            text_phone = new TextBox();
            label1 = new Label();
            label2 = new Label();
            openFileDialog1 = new OpenFileDialog();
            label3 = new Label();
            label4 = new Label();
            but_del_contact = new Button();
            text_name_del = new TextBox();
            text_phone_del = new TextBox();
            but_load = new Button();
            but_save = new Button();
            but_exit = new Button();
            SuspendLayout();
            // 
            // listBox_phone
            // 
            listBox_phone.BackColor = SystemColors.InactiveBorder;
            listBox_phone.Font = new Font("Bahnschrift", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            listBox_phone.FormattingEnabled = true;
            listBox_phone.ItemHeight = 18;
            listBox_phone.Location = new Point(522, 31);
            listBox_phone.Margin = new Padding(4, 3, 4, 3);
            listBox_phone.Name = "listBox_phone";
            listBox_phone.Size = new Size(341, 400);
            listBox_phone.TabIndex = 3;
            listBox_phone.SelectedIndexChanged += listBox_phone_SelectedIndexChanged;
            // 
            // text_name
            // 
            text_name.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            text_name.Location = new Point(13, 31);
            text_name.Margin = new Padding(4, 3, 4, 3);
            text_name.Name = "text_name";
            text_name.Size = new Size(247, 33);
            text_name.TabIndex = 4;
            // 
            // but_add_contact
            // 
            but_add_contact.BackColor = SystemColors.GradientInactiveCaption;
            but_add_contact.Font = new Font("Microsoft Sans Serif", 12.25F, FontStyle.Bold);
            but_add_contact.Location = new Point(13, 61);
            but_add_contact.Name = "but_add_contact";
            but_add_contact.Size = new Size(501, 30);
            but_add_contact.TabIndex = 5;
            but_add_contact.Text = "Добавить контакт";
            but_add_contact.UseVisualStyleBackColor = false;
            but_add_contact.Click += but_add_contact_Click;
            // 
            // text_phone
            // 
            text_phone.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            text_phone.Location = new Point(267, 31);
            text_phone.Margin = new Padding(4, 3, 4, 3);
            text_phone.Name = "text_phone";
            text_phone.Size = new Size(247, 33);
            text_phone.TabIndex = 6;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Bahnschrift", 11.25F);
            label1.Location = new Point(13, 13);
            label1.Name = "label1";
            label1.Size = new Size(104, 18);
            label1.TabIndex = 7;
            label1.Text = "Имя контакта";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Bahnschrift", 11.25F);
            label2.Location = new Point(267, 13);
            label2.Name = "label2";
            label2.Size = new Size(122, 18);
            label2.TabIndex = 8;
            label2.Text = "Номер телефона";
            // 
            // openFileDialog1
            // 
            openFileDialog1.FileName = "openFileDialog1";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Bahnschrift", 11.25F);
            label3.Location = new Point(267, 109);
            label3.Name = "label3";
            label3.Size = new Size(122, 18);
            label3.TabIndex = 13;
            label3.Text = "Номер телефона";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Bahnschrift", 11.25F);
            label4.Location = new Point(13, 109);
            label4.Name = "label4";
            label4.Size = new Size(104, 18);
            label4.TabIndex = 12;
            label4.Text = "Имя контакта";
            // 
            // but_del_contact
            // 
            but_del_contact.BackColor = Color.Plum;
            but_del_contact.Font = new Font("Microsoft Sans Serif", 12.25F, FontStyle.Bold);
            but_del_contact.Location = new Point(13, 157);
            but_del_contact.Name = "but_del_contact";
            but_del_contact.Size = new Size(501, 30);
            but_del_contact.TabIndex = 10;
            but_del_contact.Text = "Удалить контакт";
            but_del_contact.UseVisualStyleBackColor = false;
            but_del_contact.Click += but_del_contact_Click;
            // 
            // text_name_del
            // 
            text_name_del.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            text_name_del.Location = new Point(13, 127);
            text_name_del.Margin = new Padding(4, 3, 4, 3);
            text_name_del.Name = "text_name_del";
            text_name_del.Size = new Size(247, 33);
            text_name_del.TabIndex = 9;
            // 
            // text_phone_del
            // 
            text_phone_del.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            text_phone_del.Location = new Point(267, 127);
            text_phone_del.Margin = new Padding(4, 3, 4, 3);
            text_phone_del.Name = "text_phone_del";
            text_phone_del.Size = new Size(247, 33);
            text_phone_del.TabIndex = 11;
            text_phone_del.TextChanged += textBox2_TextChanged;
            // 
            // but_load
            // 
            but_load.BackColor = SystemColors.GradientInactiveCaption;
            but_load.Font = new Font("Microsoft Sans Serif", 12.25F, FontStyle.Bold);
            but_load.Location = new Point(13, 230);
            but_load.Name = "but_load";
            but_load.Size = new Size(247, 43);
            but_load.TabIndex = 14;
            but_load.Text = "Выгрузка из файла";
            but_load.UseVisualStyleBackColor = false;
            but_load.Click += but_load_Click;
            // 
            // but_save
            // 
            but_save.BackColor = SystemColors.GradientInactiveCaption;
            but_save.Font = new Font("Microsoft Sans Serif", 12.25F, FontStyle.Bold);
            but_save.Location = new Point(267, 230);
            but_save.Name = "but_save";
            but_save.Size = new Size(247, 43);
            but_save.TabIndex = 15;
            but_save.Text = "Сохранение в файл";
            but_save.UseVisualStyleBackColor = false;
            but_save.Click += but_save_Click;
            // 
            // but_exit
            // 
            but_exit.BackColor = Color.Silver;
            but_exit.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold);
            but_exit.Location = new Point(12, 279);
            but_exit.Name = "but_exit";
            but_exit.Size = new Size(501, 45);
            but_exit.TabIndex = 16;
            but_exit.Text = "Назад";
            but_exit.UseVisualStyleBackColor = false;
            but_exit.Click += but_exit_Click;
            // 
            // FormParams
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(877, 450);
            Controls.Add(but_exit);
            Controls.Add(but_save);
            Controls.Add(but_load);
            Controls.Add(label3);
            Controls.Add(label4);
            Controls.Add(but_del_contact);
            Controls.Add(text_name_del);
            Controls.Add(text_phone_del);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(but_add_contact);
            Controls.Add(text_name);
            Controls.Add(listBox_phone);
            Controls.Add(text_phone);
            Name = "FormParams";
            Text = "Параметры";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListBox listBox_phone;
        private TextBox text_name;
        private Button but_add_contact;
        private TextBox text_phone;
        private Label label1;
        private Label label2;
        private OpenFileDialog openFileDialog1;
        private Label label3;
        private Label label4;
        private Button but_del_contact;
        private TextBox text_name_del;
        private TextBox text_phone_del;
        private Button but_load;
        private Button but_save;
        private Button but_exit;
    }
}