namespace zd2_Varaxin
{
    public partial class Form1 : Form
    {
        PhoneBook phoneBook;

        public Form1()
        {
            phoneBook = new PhoneBook();
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void but_params_Click(object sender, EventArgs e)
        {
            listBox_phone.Items.Clear();
            FormParams form_params = new FormParams(phoneBook);
            form_params.ShowDialog();

            listBox_phone.Items.AddRange((from con in phoneBook.ListPhone()
                                          select con.Info()).ToArray<string>());
        }

        private void but_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void but_search_Click(object sender, EventArgs e)
        {
            text_search.BackColor = Color.White;
            if (listBox_phone.Items.Count == 0)
            {
                MessageBox.Show("���������� ����� �����", "�����");
                text_search.Text = "";
                return;
            }

            if (text_search.Text == "")
            {
                text_search.BackColor = Color.Tomato;
                return;
            }

            int count = 0;
            string result = "";

            for (int i = 0; i < listBox_phone.Items.Count; i++)
            {
                if (listBox_phone.Items[i].ToString().Contains(text_search.Text))
                {
                    count++;
                    result += listBox_phone.Items[i].ToString() + "\n";
                }
            }

            if (count > 0)
            {
                MessageBox.Show(result, $"������� {count} ����������");
            }
            else
            {
                MessageBox.Show("������ �� �������", "����� �� ������");
            }
            
        }
    }
}
